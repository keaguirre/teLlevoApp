from django.apps import AppConfig


class MovilapiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'movilAPI'
